<p>Posted by: Aakash Patel</p>
  <p>Contact information: <a href="mailto:apatel2564@conestogac.on.ca">aakash patel</a>.</p>
  <p><a href ="www.google.com">google.com</a>
  <p><a href ="www.facebook.com">google.com</a><p><a href ="www.facebook.com">google.com</a>
  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Php project 1</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li><a href="store.php">Store</a></li>
     
    </ul>
  </div>
</nav>